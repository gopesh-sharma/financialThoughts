var store = [{
        "title": "Hello Finance Enthusiasts",
        "excerpt":"It’s always important for any individual to share any new things he learns or he has been doing in his life. Through this blog, I will be doing the same, which means I will try to share with all financial enthusiasts about my financial journey and how I will be...","categories": ["blog"],
        "tags": ["finance"],
        "url": "http://localhost:4001/blog/hello-finance-enthusiasts/"
      },{
        "title": "The Fundamentals of Personal Finance",
        "excerpt":"You’ve got your budget, and you’ve got your savings, this is what everyone else but what else can you do? Well, how about doing some smart financial decisions that will make sure you have enough money for everything and then some? It’s easy to get caught up in the day-to-day...","categories": ["Basics"],
        "tags": ["finance","beginner"],
        "url": "http://localhost:4001/basics/fundamentals-personal-finance/"
      },{
        "title": "The Fundamentals of Personal Finance - Creating Budget",
        "excerpt":"The most important fundamentals of personal finance is to have a Budget. This is like the first step towards your financial journey. A budget is a way to keep track of your spending, so that you can make sure that it’s not going out of control. It also helps you...","categories": ["Basics"],
        "tags": ["finance","beginner","budget"],
        "url": "http://localhost:4001/basics/creating-budget/"
      },{
        "title": "The Fundamentals of Personal Finance - Managing Budget",
        "excerpt":"No matter how much money you make, it’s always important to budget carefully and manage your finances wisely. As we all know that most important fundamentals of personal finance is to have a Budget. But for many people, budgeting can seem like a daunting task. Making a budget is one...","categories": ["Basics"],
        "tags": ["finance","beginner","budget"],
        "url": "http://localhost:4001/basics/managing-budget/"
      },{
        "title": "The Best Budgeting Methods to Consider for Financial Success",
        "excerpt":"You have learned about Creating Budget and Maintaining It and have taken the first step towards your financial journey. There are a lot of budgeting methods which you can consider when you are creating a budget or maintaining it. These different budgeting methods can be simple or complicated and thus...","categories": ["Budgeting"],
        "tags": ["finance","beginner","budget","budgeting methods"],
        "url": "http://localhost:4001/budgeting/budgeting-methods/"
      },{
        "title": "Easy Strategies for Establishing Balance in Your Budget",
        "excerpt":"Whenever we talk about the budget, the basic thing to look out for is the balance and it is the key of having a great budget. You don’t have to be so tight in your budget that you don’t enjoy your life but at the same time you don’t want...","categories": ["Budgeting"],
        "tags": ["finance","beginner","budget"],
        "url": "http://localhost:4001/budgeting/balance-in-budget/"
      },{
        "title": "Strategies for Dealing With Unexpected Expenses in Your Budget",
        "excerpt":"It’s the middle of the month, and you’re staring at an unexpected expense. You’re not sure where it came from, but now you need to come up with $500 fast. What do you do? It can be tough to deal with unexpected expenses, especially if they come as a surprise....","categories": ["Budgeting"],
        "tags": ["finance","beginner","budget"],
        "url": "http://localhost:4001/budgeting/unexpected-expense-in-budget/"
      },{
        "title": "Financially Prepared: Master Your Personal Finance Annual Review",
        "excerpt":"Here we are at the end of 2022 and It’s that time of year again where people usually go through all the goals and plans for the year and see where do you stand. It’s that time, where you give budget a check-up and see where you can make improvements...","categories": ["Basics"],
        "tags": ["finance","beginner","budget","annual review"],
        "url": "http://localhost:4001/basics/personal-finance-annual-review/"
      },{
        "title": "Everything You Need to Know About Building a Personal Emergency Fund",
        "excerpt":"A personal emergency fund is one of the most important things you should have in your financial arsenal. It is just like a savings account set aside only for emergencies. The money in this account can be used to cover unexpected expenses that come up, such as job loss, car...","categories": ["Basics"],
        "tags": ["finance","beginner","emergency fund"],
        "url": "http://localhost:4001/basics/personal-emegency-fund/"
      },{
        "title": "Unlock Your Financial Potential: A Comprehensive Guide for Beginner Investors",
        "excerpt":"In every financial post you might have read about investing and how it helps to achieve financial freedom, everyone suggests that you should start investing as early as possible. But the question is, where do you begin? What types of investments are appropriate for beginners? And how do you avoid...","categories": ["Basics"],
        "tags": ["finance","beginner","investing"],
        "url": "http://localhost:4001/basics/guide-beginner-investor/"
      },{
        "title": "How to Cope With Financial Loss and Move Forward",
        "excerpt":"No one like to lose money, but sometimes you can’t help it. The problem lies when you do not know how to cope up with the financial loss and move forward. If you’ve recently lost money and don’t know how to move forward, then this post is for you. Let...","categories": ["Basics"],
        "tags": ["finance","beginner","financial loss"],
        "url": "http://localhost:4001/basics/financial-loss/"
      },{
        "title": "From Resolutions to Real Results: Boost Your Personal Finances With Action",
        "excerpt":"You’re at the beginning of a new year, and like most people, you’re thinking about your resolutions. This year, forget about vague plans to “save more” or “spend less.” Those never seem to work, do they? This year, take specific and measurable action to boost your personal finances. Financial resolutions...","categories": ["Basics"],
        "tags": ["finance","beginner","personal finance"],
        "url": "http://localhost:4001/basics/resolutions-to-results-in-personal-finance/"
      },{
        "title": "Making Sense of Your Finances: What Should Be Included in Your Budget",
        "excerpt":"The most important fundamentals of personal finance is to have a Budget. Your financial journey begins with creating a budget. So if you have started making a Budget, the congrats on taking the first step towards your personal financial journey. By doing this, you will be able to improve your...","categories": ["Budgeting"],
        "tags": ["budget"],
        "url": "http://localhost:4001/budgeting/included-in-budget/"
      },{
        "title": "The Right Way to Accurately Track Your Living Expenses With a Budget",
        "excerpt":"In our previous posts, we have read about how to create a budget, how to manage it and what should be included in your budget. We all know that Living Expenses are necessary for a human being but you should also track it in your budget so that you are...","categories": ["Budgeting"],
        "tags": ["finance","budget"],
        "url": "http://localhost:4001/budgeting/living-expenses-budget/"
      },{
        "title": "Manage Your Money With the 50/30/20 Rule of Budgeting",
        "excerpt":"When we talk about Budgets, there are a lot of budgeting methods which people consider when they are creating the budget. These different budgeting methods can be simple or complicated and most of them don’t even work. Since everyone is different as well as unique, their budget should also be...","categories": ["Budgeting"],
        "tags": ["finance","beginner","budgeting"],
        "url": "http://localhost:4001/budgeting/manage-money-budgeting-methods-personal-finance/"
      },{
        "title": "From Basics to Beyond: A Guide to Mastering Zero-Based Budgeting",
        "excerpt":"You all know that putting your money to work is the best way to maximize the gain as well as to attain financial freedom. The more money working for you, the nearer you are to attaining financial freedom as well as maximizing your financial potential. Now just allocating the money...","categories": ["Budgeting"],
        "tags": ["beginner","budgeting"],
        "url": "http://localhost:4001/budgeting/zero-based-budgeting/"
      },{
        "title": "Get Started With Envelope Budgeting: A Guide for Beginners",
        "excerpt":"If you are having a hard time-saving money then it’s time to consider the envelope budgeting method. Envelope budgeting is a simple but effective method of managing finances. In this type of budgeting method, you are setting a fixed amount of money to specific categories. What is Envelop Budgeting Technique?...","categories": ["Budgeting"],
        "tags": ["beginner","budgeting"],
        "url": "http://localhost:4001/budgeting/envelop-budgeting-begineer/"
      },{
        "title": "Budget Blunders: The Dangers of Using Debit and Credit Cards",
        "excerpt":"Ever thought that what would have happened to your spending if you don’t own any cards be it credit or debit card. The spending will decrease because these cards make it easier to overspend. The cards allow for instant and convenient purchases without the need to hand over cash. When...","categories": ["Budgeting"],
        "tags": ["beginner","budgeting","credit card","debit card"],
        "url": "http://localhost:4001/budgeting/budget-blunders-credit-debit-cards/"
      },{
        "title": "6 Ways to Ease Financial Stress With a Budget",
        "excerpt":"You might have heard the wise financial advice to make a budget. Having a budget is one of the most important fundamentals of personal finance. A budget allows you to keep track of your spending and ensure that it is not out of control. It also helps you achieve your...","categories": ["Budgeting"],
        "tags": ["beginner","budgeting"],
        "url": "http://localhost:4001/budgeting/ease-financial-stress-with-budget/"
      },{
        "title": "Free Yourself From Debt With This Simple Step-by-Step Guide",
        "excerpt":"Debt is one of the silent killers of an individual’s hopes for becoming financially free. Debt is a heavy burden to carry and thus we feel overwhelmed by the mere thought of paying it off. It’s important to pay off your debt as soon as possible to progress in your...","categories": ["Budgeting"],
        "tags": ["beginner","debt"],
        "url": "http://localhost:4001/budgeting/free-yourself-from-debt/"
      },{
        "title": "Managing Your Finances Through the Pay Yourself First Budgeting Method",
        "excerpt":"The “Pay Yourself First” is the budgeting strategy where people will prioritize saving by setting aside some portion of their income into savings or investments. This is done before paying any bill or making any other purchases. The idea of “Pay Yourself First” is simple people should cultivate saving as...","categories": ["Budgeting"],
        "tags": ["beginner","budgeting"],
        "url": "http://localhost:4001/budgeting/pay-yourself-first-budgeting-method/"
      },{
        "title": "6 Low-Risk Investments for First-Time Investors",
        "excerpt":"For first-time investors, finding out where to invest is a daunting task. So it’s better to start with low-risk investments to learn the nitty-gritty of the investments. With the education and the right strategy, you can build your portfolio for the long term. The problem faced by first-time investors is...","categories": ["Investments"],
        "tags": ["beginner","investment"],
        "url": "http://localhost:4001/investments/low-risk-investments/"
      }]
