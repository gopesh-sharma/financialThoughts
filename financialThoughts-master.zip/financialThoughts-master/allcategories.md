---
title: Category Archive
layout: categories
permalink: /allcategories/
show_excerpts: true
entries_layout: list
---
