---
title: Let's Get Connected
layout: page
permalink: /contact/
---

If you want to discuss about new technologies, best practices, hosting any meetup, or about my work, you are certainly welcome. I will reply as soon as possible.

* Twitter: @gopu18
* Address: Bangalore, India